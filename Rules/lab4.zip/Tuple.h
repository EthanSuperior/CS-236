#ifndef RELATIONAL_DATABASE_TUPLE_H
#define RELATIONAL_DATABASE_TUPLE_H


#include <vector>
#include <string>

class Tuple : public std::vector<std::string>{};


#endif //RELATIONAL_DATABASE_TUPLE_H

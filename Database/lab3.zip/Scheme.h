#ifndef RELATIONAL_DATABASE_SCHEME_H
#define RELATIONAL_DATABASE_SCHEME_H


#include <string>
#include <vector>

class Scheme : public std::vector<std::string>{};


#endif //RELATIONAL_DATABASE_SCHEME_H
